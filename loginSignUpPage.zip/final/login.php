<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    
    <div id="center" class="w-25 p-3 mx-auto  text-#101820FF">
        <br>
        <h1>Log in</h1>
        <form action="server.php" method="post">
            <u>Email:</u><input type="text" name="loginemail" class="form form-control mt-2 ">
            <u>Password:</u><input type="password" name="loginpassword" class="form form-control mt-2 ">
            <button id="save" name="login" class="btn  mt-2">Log in</button><br><br>
            
        </form>
            <p>Don't have account? <a href="index.php">Sign up</a><p>
    </div>
       
    <?php
        $url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        if(strpos($url, "login=field") == true){
            echo "<script>alert('Wrong email or password')</script>";
            exit();
        }else if(strpos($url, "login=email")==true){
            echo "<script>alert('You did not fill the email!')</script>";
            exit();
        }else if(strpos($url, "login=password")==true){
            echo "<script>alert('You did not fill the password!')</script>";
            exit();
        }

        session_destroy();
    ?>

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="script.js"></script> -->
</body>

</html>