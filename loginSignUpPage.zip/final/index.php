<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  
    
    <div id="center" class="w-25 p-3 mx-auto  text-#101820FF">
    <br>
    <h1>Sign up</h1>
       
        <u>Name:</u><input type="text" name="name" class="form form-control mt-2 name">
       
        <u>Surname:</u><input type="text" name="surname" class="form form-control mt-2 surname">
        
        <u>Age:</u><input type="text" name="age" class="form form-control mt-2 age">
        
        <u style="margin-right: 5px;">Male:</u><input type="radio" name="gender" class=" mt-2 gender" value="male"  style="margin-right: 50px;">
        <u style="margin-right: 5px;">Female:</u><input type="radio" name="gender" class="mt-2 gender" value="female">
       <br>
        <u>Email:</u><input type="text" name="email" class="form form-control mt-2 email">

        <u>Password:</u><input type="password" name="password" class="form form-control mt-2 password">
       
        <u>Confirm password:</u><input type="password" name="confirm" class="form form-control mt-2 confirm">
       
        <button  id = "save"class="btn  mt-2 save">Save</button>
        <br>
        <br>
        <p>Already have account? <a href="login.php">Log in</a><p>
    </div>

  

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="script.js"></script>
</body>
</html>