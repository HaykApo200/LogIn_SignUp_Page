
$(document).ready(function(){
    // $(".save").click(function(){
    //     let name = $(".name").val();
    //     let surname = $(".surname").val();
    //     let age = $("age").val();
    //     let gender = $("input[name='gender']:checked").val();
    //     let email = $("eamil").val();
    //     let password = $("password").val();
    //     let confirm = $("confirm").val();

    $(".save").click(function(){
        let user ={
            name :$(".name").val(),
            surname :$(".surname").val(),
            age: $(".age").val(),
            gender: $("input[name='gender']:checked").val(),
            email: $(".email").val(),
            password: $(".password").val(),
            confirm: $(".confirm").val()
        }  ////above
         
        $.ajax({
            type: "post",
            url: "server.php",
            data: {
                user: user,
                action:"ajax",
            },
            success: function(r){
                console.log(r);
                if(r  == 1){
                   window.location.href = "./login.php"
                }else{
                    r = JSON.parse(r);
                    if("error_name" in r){
                        $(".name").val("");
                        $(".name").attr("placeholder", r.error_name)
                    }

                    if("error_surname" in r){
                        $(".surname").val("");
                        $(".surname").attr("placeholder", r.error_surname)
                    }

                    if("error_age" in r){
                        $(".age").val("");
                        $(".age").attr("placeholder", r.error_age)
                    }

                    if("error_email" in r){
                        $(".email").val("");
                         $(".email").attr("placeholder", r.error_email)
                    }

                    if("error_password" in r){
                        $(".password").val("");
                         $(".password").attr("placeholder", r.error_password)
                    }

                    if("error_confirm" in r){
                        $(".confirm").val("");
                         $(".confirm").attr("placeholder", r.error_confirm)
                    }
                }
            }
        })
    })
})