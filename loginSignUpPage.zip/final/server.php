<?php
ob_start();
class Controller{
    function __construct()
    {
        if($_SERVER['REQUEST_METHOD']="POST"){
            $this->db = new mysqli('localhost','root','','hayk');
            if(isset($_POST['action'])){
                if($_POST['action'] == "ajax"){
                    $this->addUser();
                }
            }
            if(isset($_POST['login'])){
                    $this->loginPage();
            }
        }   
    }

    function addUser(){
        // $name = $_POST['name'];
        // $surname = $_POST['surname'];
        // $age = $_POST['age'];
        // $gender = $_POST['gender'];
        // $email = $_POST['email'];
        // $password = $_POST['password'];
        // $confirm = $_POST['confirm'];
        extract($_POST['user']);
        $error = [];

        if(empty($name)){
            $error['error_name'] = "Fill the name";
        }

        if(empty($surname)){
            $error['error_surname'] = "Fill the surname";
        }

        if(empty($age)){
            $error['error_age'] = "Fill the age";
        }else if(!filter_var($age, FILTER_VALIDATE_INT)){
            $error['error_age'] = "Write age correctly";
        }

        if(empty($email)){
            $error['error_email'] = "Fill the email";
        }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $error['error_email'] = "Write email correctly";
        }

        if(empty($gender)){
            $error['error_gender'] = "Select the gender";
        }

        if(empty($password)){
            $error['error_password'] = "Fill the password";
        }else if(strlen($password)<6){
            $error['error_password'] = "Password is less than 6";
        }

        if(empty($confirm)){
            $error['error_confirm'] = "Fill the confirm";
        }else if($password !== $confirm){
            $error['error_confirm'] = "Wrong password";  
        }
        
        if(count($error)>0){
            print json_encode($error);
        }
        else{
            $hash = password_hash($password, PASSWORD_DEFAULT);
            // password_verify($password,$hash);
            $this->db->query("INSERT INTO `users`(
                `name`,`surname`,`age`,`gender`,`email`,`password`)
            VALUES('$name','$surname','$age','$gender','$email','$hash')");
            
            print 1;
        }
    }
    function loginPage(){
        $loginemail = $_POST['loginemail'];
        $loginpassword = $_POST['loginpassword'];
       
        if(empty($loginemail)){
            header("location: login.php?login=email");
        }else if(empty($loginpassword)){
            header("location: login.php?login=password");
        }else if(isset($loginemail) && isset($loginpassword)){
            $data = $this->db->query("SELECT * FROM `users` WHERE `email` = '$loginemail'")->fetch_all(true);
            if(!password_verify($loginpassword, $data[0]['password'])){
                header("location: login.php?login=field");
            }else{
                $_SESSION['data'] = $data[0];
                header("location: user.php");
            }
        }
    }
}

new Controller();
ob_end_flush();

?>
