

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <style>
        body{
            width: 100vw;
            height: 100vh;
            padding: 0;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #101820FF;
        }
    
        .text{
            color:#FEE715FF;
            font-size: 270px;
            text-shadow: 0px 0px 20px #FEE715FF;
        }

        .center{
            height: 100vh;
            width: 100vw;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .btn{
            height: 70px;
            width: 150px;
            background-color:#FEE715FF;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        a{
            color:#101820FF;
            text-decoration: none;
            font-size: 30px;
        }
    </style>
</head>
<body>
    <div class="center">
        <div class="text">Welcome</div>
        <div class="btn"><div><a href="login.php">Log out</a></div></div>
    </div>
</body>
</html>


